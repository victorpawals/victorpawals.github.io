window.onload = getContent();

var slideIndex = 0;

var dataInfo = null

var testinginterval = function(){
$(".slideshow").html(chooseInfo())};

var interval = setInterval(testforintervall, 3000);

var timeout = setTimeout(testforintervall, 3000);


function nextSlide() {
	 var first = dataInfo.uutiset[0].otsikko
	 var second = dataInfo.uutiset[1].otsikko
	 var third =dataInfo.uutiset[2].otsikko
	
	 if(current == first){
		 current = second
	 }else if (current == second){
		 current = third
	 } else {
		 current = first
	 }
 }
	

 var current = first
 
 function chooseInfo() {
	 var first = dataInfo.uutiset[0].otsikko
	 var second = dataInfo.uutiset[1].otsikko
	 var third =dataInfo.uutiset[2].otsikko
	 if(current == first){
		 current = second
	 }else if (current == second){
		 current = third
	 } else {
		 current = first
	 }
	 return current
 }
 
function getContent(){
	$.getJSON('https://project-6883488650295468045.firebaseio.com/.json',
	 function(data){
		console.log(data);
		dataInfo = data;
	 })
}

showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
	timeout;
}















